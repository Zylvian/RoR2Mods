# Bet On It

This mod adds the highly requested functionality of Zac Efron blaring "BET ON IT" after every Altar of Luck purchase.

## Changelog

**1.0.1**
* Added an actual .dll.

**1.0.0**

* Mod created.
