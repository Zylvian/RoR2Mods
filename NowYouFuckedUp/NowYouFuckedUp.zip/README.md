# Angry Lemurians

The Elder Lemurians seem to think that you have fucked up.

https://streamable.com/0on60w

## Changelog

**1.0.1**
* Restructured the entire mod to configure the Elder Lemurian prefab as opposed to hooking events.
* In short: better performance, less bugs.

**1.0.0**
* Added angry Lemurians to the game.
